// src/icons.js
import { library } from '@fortawesome/fontawesome-svg-core';
import { faHandPaper, faEye, faBullseye } from '@fortawesome/free-solid-svg-icons';

library.add(faHandPaper, faEye, faBullseye);
