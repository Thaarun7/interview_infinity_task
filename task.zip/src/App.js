import DashBoard from "./Page/DashBoard";


function App() {
  return (
   <DashBoard/>
  );
}

export default App;
